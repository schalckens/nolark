<?php

header("Location: mailto:jose.gil@ac-nice.fr");
